package com.klu;
class Vehicle{
	void startVehicle() {
		System.out.println("vehicle started");
	}
}

class Car extends Vehicle{
	void driveCar() {
		System.out.println("driving car");
	}
}
class ElectricCar extends Car{
	void driveElectric() {
		System.out.println("driving electric car");
	}
}

public class inheritenceexe {
	public static void main(String[]args) {
		ElectricCar b1 = new ElectricCar();
		
		b1.startVehicle();
	
		b1.driveElectric();
	}

}
