package com.klu;
class Bank{
	double getInterestRate() {
		return 0.0;
		
	}
	void showInterest() {
		System.out.println("Ineterest rate: "+ getInterestRate()+"%");
		
	}
}
class SBI extends Bank{
	@Override
	double getInterestRate() {
		return 2.5;
		
	}
}
class HDFC extends Bank{
	@Override
	double getInterestRate() {
		return  5.3;
	}
}

public class DemoBank {
	public static void main(String[]args) {
		Bank b1 = new SBI();
		Bank b2 = new HDFC();
		System.out.println();
		b1.showInterest();
		System.out.println();
		b2.showInterest();
	}
	

}
